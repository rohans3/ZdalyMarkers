﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ZdalyMarkers.Interface;
using ZdalyMarkers.Models;

namespace ZdalyMarkers.DAL
{
    public class MarkerDataAccessLayer : IMarkerManager
    {
        public IEnumerable<ZdalyMarker> GetAllMarkers()
        {
            var list = new List<string>();
            string filepath = @"wwwroot/Data/Data.csv";


            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(filepath))
            {
                string[] headers = sr.ReadLine().ToString().Replace("\"", "").Split(';');
               
                foreach (string header in headers)
                {
                    dt.Columns.Add(header);
                }
                while (!sr.EndOfStream)
                {
                    string[] rows = sr.ReadLine().ToString().Replace("\"", "").Split(';');
                    //Regex.Split(sr.ReadLine(), ";(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
                    DataRow dr = dt.NewRow();
                    ZdalyMarker zmRow = new ZdalyMarker();
                    for (int i = 0; i < headers.Length; i++)
                    {

                        dr[i] = rows[i]; //this is the line that is causing the error
                    }
                    dt.Rows.Add(dr);
                }
            }

            return ConvertToZdalyMarkers(dt);

        }
        private IEnumerable<ZdalyMarker> ConvertToZdalyMarkers(DataTable dataTable)
        {
            foreach (DataRow row in dataTable.Rows)
            {
                yield return new ZdalyMarker
                {
                    
                    STATION_ID = row["STATION_ID"] != null ? Convert.ToInt32(row["STATION_ID"]): 0,
                    SITE_NAME = row["SITE_NAME"] != null ? Convert.ToString(row["SITE_NAME"]) : "",
                    ZDALY_GAS_BRAND = row["ZDALY_GAS_BRAND"] != null ? Convert.ToString(row["ZDALY_GAS_BRAND"]) : "",
                    ADDRESS = row["ADDRESS"] != null ? Convert.ToString(row["ADDRESS"]) : "",
                    CITY = row["CITY"] != null ? Convert.ToString(row["CITY"]) : "",
                    STATE = row["STATE"] != null ? Convert.ToString(row["STATE"]) : "",
                    ZIP = row["ZIP"] != null ? Convert.ToInt32(row["ZIP"]) : 0,
                    COUNTY_NAME = row["COUNTY_NAME"] != null ? Convert.ToString(row["COUNTY_NAME"]) : "",
                    PRICING_ZONE = row["PRICING_ZONE"] != null ? Convert.ToString(row["PRICING_ZONE"]) : "",
                    CLUSTER_MEDIAN_PRICE = row["CLUSTER_MEDIAN_PRICE"] != null && row["CLUSTER_MEDIAN_PRICE"] != "" ? Convert.ToDecimal(row["CLUSTER_MEDIAN_PRICE"]) : 0,
                    CLIENT_MARKET_PRICE = row["CLIENT_MARKET_PRICE"] != null && row["CLIENT_MARKET_PRICE"] != "" ? Convert.ToDecimal(row["CLIENT_MARKET_PRICE"]) : 0,
                    LATITUDE = row["LATITUDE"] != null && row["LATITUDE"] != "" ? Convert.ToDecimal(row["LATITUDE"]) : 0,
                    LONGITUDE = row["LONGITUDE"] != null && row["LONGITUDE"] != "" ? Convert.ToDecimal(row["LONGITUDE"]) : 0
                };
            }

        }

    }
}
