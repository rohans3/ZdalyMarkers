﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ZdalyMarkers.Interface;
using ZdalyMarkers.Models;

namespace ZdalyMarkers.Controllers
{
    public class MarkerController : Controller
    {
        private readonly IMarkerManager markerService;
        private const int DefaultPageSize = 10;
        public MarkerController(IMarkerManager _markerService)
        {
            markerService = _markerService;
        }

        public IActionResult Index()
        {
            return View(this.GetMarkers(1));
        }
        [HttpPost]
        public IActionResult Index(int currentPageIndex)
        {
            return View(this.GetMarkers(currentPageIndex));
        }
        
        public JsonResult GetMapMarkers()
        {
            List<ZdalyMarker> lstMarker = new List<ZdalyMarker>();
            lstMarker = markerService.GetAllMarkers().ToList();
           
            return new JsonResult(lstMarker.Select(i => new { i.LATITUDE, i.LONGITUDE,i.SITE_NAME }));
        }
        private ZdalyMarkerModel GetMarkers(int currentPage)
        {
            int maxRows = 30;
            ZdalyMarkerModel zdalyModel = new ZdalyMarkerModel();
            List<ZdalyMarker> lstMarker = new List<ZdalyMarker>();
            lstMarker = markerService.GetAllMarkers().ToList();
            zdalyModel.ZdalyMarker = lstMarker.Skip((currentPage - 1) * maxRows)
                        .Take(maxRows).ToList();            
            double pageCount = (double)((decimal)lstMarker.Count() / Convert.ToDecimal(maxRows));
            zdalyModel.PageCount = (int)Math.Ceiling(pageCount);
            zdalyModel.CurrentPageIndex = currentPage;
            ViewData["Cluster"] = string.Join(",", lstMarker.Select(l => l.CLUSTER_MEDIAN_PRICE));
            ViewData["Client"] = string.Join(",", lstMarker.Select(l => l.CLIENT_MARKET_PRICE));
            return zdalyModel;
        }
    }
}
