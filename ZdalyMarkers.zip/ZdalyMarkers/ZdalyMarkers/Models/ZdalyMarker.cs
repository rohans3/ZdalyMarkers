﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ZdalyMarkers.Models
{
    public class ZdalyMarkerModel
    {
        ///<summary>
        /// Gets or sets Customers.
        ///</summary>
        public List<ZdalyMarker> ZdalyMarker { get; set; }

        ///<summary>
        /// Gets or sets CurrentPageIndex.
        ///</summary>
        public int CurrentPageIndex { get; set; }

        ///<summary>
        /// Gets or sets PageCount.
        ///</summary>
        public int PageCount { get; set; }
    }

    public class ZdalyMarker
    {

        public int STATION_ID{ get; set; }  
        public string SITE_NAME{ get; set; } 
        public string ZDALY_GAS_BRAND { get; set; } 
        public string ADDRESS { get; set; }
        public string CITY { get; set; }
        public string STATE { get; set; } 
        public int ZIP{ get; set; } 
        public string COUNTY_NAME { get; set; }
        public string PRICING_ZONE { get; set; } 
        public decimal CLUSTER_MEDIAN_PRICE { get; set; }  
        public decimal CLIENT_MARKET_PRICE { get; set; }
        public decimal LATITUDE { get; set; }  
        public decimal LONGITUDE { get; set; }
    }
}
